<?php
    require_once './twig/lib/Twig/Autoloader.php';
    Twig_Autoloader::register();

    $loader = new Twig_Loader_Filesystem('./templates');
    $twig = new Twig_Environment($loader);

    $success = False;
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = $_POST['name'];
//        $lname = $_POST['lname'];
        $email = $_POST['email'];

//        $country = $_POST['country'];
//        $state = $_POST['state'];

        $mobile = $_POST['mobile'];
//        $work = $_POST['work'];
//        $address= $_POST['address'];

        $subject = "Contact Us Form - Bhairaav Darshan ".$email." ".$mobile;
        $email_message = "Email: ".$email;
        $email_message = $email_message."\nName: ".$name."\nLastName: ".$lname;
        $email_message = $email_message."\nMobile: ".$mobile."\nWork: ".$work;
//		$email_message = $email_message."\nAddress: ".$address;
//        $email_message = $email_message."\nCountry: ".$country;
//        

        $from = "no-reply@bhairaavsignature.com";
        $to = "sales@bhairaavlifestyles.com";

        mail($to, $subject, $email_message, "From: ".$from);
        if ($email) {
            $success = True;
        }
    } 

    echo $twig->render('bhairaav_darshan.html', array('success' => $success, ));
?>
