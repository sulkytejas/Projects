<?php
    require_once './twig/lib/Twig/Autoloader.php';
    Twig_Autoloader::register();

    $loader = new Twig_Loader_Filesystem('./templates');
    $twig = new Twig_Environment($loader);

    $success = False;
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $email = $_POST['email'];

        $country = $_POST['country'];
//        $state = $_POST['state'];

        $mobile = $_POST['mobile'];
        $work = $_POST['work'];
        $address= $_POST['address'];

        $subject = "Contact Us Form - ".$email." ".$mobile;
        $email_message = "Email: ".$email;
        $email_message = $email_message."\nFirstName: ".$fname."\nLastName: ".$lname;
        $email_message = $email_message."\nMobile: ".$mobile."\nWork: ".$work;
		$email_message = $email_message."\nAddress: ".$address;
        $email_message = $email_message."\nCountry: ".$country;
        

        $from = "no-reply@bhairaavsignature.com";
        $to = "info@bhairaavlifestyles.com";

        mail($to, $subject, $email_message, "From: ".$from);
        if ($email) {
            $success = True;
        }
    } 

    echo $twig->render('contact.html', array('success' => $success, ));
?>
