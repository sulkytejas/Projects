<!DOCTYPE html>
<html>
    <head>
         <title>Minus</title>
        <meta name="viewport" width="device-width,initial-scale=1.0">

        <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link href='http://fonts.googleapis.com/css?family=PT+Sans:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
        
        <link rel="stylesheet" href="http://blueimp.github.io/Gallery/css/blueimp-gallery.min.css">
        <link rel="stylesheet" href="css/bootstrap-image-gallery.min.css">




        <style type="text/css">
<!--
.style1 {color: #AFC621}
-->
        </style>
    </head>
    
    <body>
        <div class="main about">
            <div class="header"> 
                <div class="container1">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="container">
                                <div class="logo-section">
                                    <a href="index.php"><img src="image/logo.png" class="logo"/> </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-offset-2 col-md-offset-0 col-md-8">
                            <div class="social"> 
                              <span class="txt" >CONNECT WITH US</span> 
                              <span class="logos">
                                <a href="http://www.facebook.com/minusslimming" target="_blank">    <img src="image/fb.png" style="margin-bottom:-9px"></a> 
                                <a href="http://www.twitter.com/minusslimming" target="_blank">    <img src="image/twitter.png" style="margin-bottom:-9px"> </a>
                                  <a href="http://www.minusslimming.blogspot.in" target="_blank"> <img src="image/print.png" style="margin-bottom:-9px"> </a>
                              </span>  
                            </div>
                            <div class="menu">
                                <div class="navbar navbar-default menu">
                                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navHeaderCollapse">
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                
                                    </button>
                                
                                    <div class="collapse navbar-collapse navHeaderCollapse">
                                        <ul class="nav navbar-nav navbar-right">
                                            <li> <a href="index.php" >HOME</a> </li>
                                            <li> <a href="about_us.php"><span style="color:#4a68af">ABOUT US </span></a> </li>
                                            <li> <a href="treatment.php">TREATMENT</a> </li>
                                            <li class="dropdown">
                                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">TOOLS</a>
                                                <ul class="dropdown-menu">
                                                    <li class="il-border "><a href="bmi.php">BMI CALCULATOR</a></li>
                                                    <li class="calorie"><a href="calorie.php">CALORIE CHART</a></li>
                                                </ul>
                                            </li>
                                            <li> <a href="faq.php">FAQS</a> </li>
                                            <li> <a href="career.php">CAREERS</a> </li>
                                            <li> <a href="Contact.php">CONTACT US</a> </li>
                                        </ul>
                                    </div>
                                
                                </div>
                           </div>                        
                       </div>
                  </div>
              </div>
          </div>
                        <div class="location" style="backround-color:#ed6094" >
                            <img src="image/about%20us%20banner.jpg" class="img-responsive" alt="Responsive image" style="margin-left:12%">
                    
                        </div>
                        <div class="grid">
                            <div class="container1">
                                <div class="row">
                                    <div class="col-md-8 middle-container">
                                            <h1> <span class="header-grid" >ABOUT US </span>  </h1>
                                            <div class="middle-body"> 
                                             <p> 
                                                Are 'hard stubborn pockets' bothering you too much?<br>
                                                Are you looking for a visible fat loss solution? <br>
                                               Are you on the lower end or higher end of the BMI? <br>
                          Do you have small amounts of localized fat such as behind the knee, in the breast region, under the arms or chin and face?<br> 
                                                 Do you want to avoid surgery? <br> <br>
                                                 
                                                 Well, <span class="bold"> Minus Slimming Centre </span>  is the right place for you!!!<br> <br>

We are a modern Slimming & Body shaping clinic that uses 3rd Generation Ultrasound technology, a non-invasive procedure that eliminates fat cells using ultrasonic technology. The treatment breaks down fatty tissue and fat cells are removed naturally via the body's lymphatic and metabolic pathways. With our highly qualified team of doctors we assure that we would minus the excess (fat) helping you achieve the perfect shape. <br> <br>
                                                 
                                                 The greatest change, based on smart this effective and safe technology is the expanding gift of non- surgical fat reduction treatments based on high tech medical machines harnessing ultrasound lipolysis. This is an easy and much more convenient body engraving procedure. If you think that you want to change your image, you can consider U-lipolysis because this is going to change your life forever.<br> <br>
                                                 U-Lipolysis uses a new Ultrasound lipolysis &amp;Tripolar RF based system, making it a safe, painless and non-surgical way to get rid of excess fat from your waist and get your body back in shape.Advanced Tripolar RF technology delivers the optimal RF energy to the dermal &amp; subcutaneous layers, causing collagen regeneration, collagen remodeling &amp; skin tightening.<br> <br>
                                               <span class="bold">  How does Ultrasonic U lipolysis work?</span><br>
The Ultrasonic Cavitation machine uses sound waves/frequencies to disrupt the fat cell walls, which causes the fat cells to "leak" their contents into the fluid spaces of your body. From there, your Lymphatic system picks up this waste material (the loose fat) and begins circulating it through your body until it can be processed by the liver and eliminated with sweat, urine and feces. The results are visibly noticeable immediately, however the entire process can take several days, and you will continue to experience results during this time.
                                                 
                                              </p>  
                                            </div>

                                            
                                    </div>
                                    
                                          <div class="col-md-4 feedback">
                                           <form class="form-horizontal" method="post" name="contact_form" id="signup">
                                            <h1 class="top-header"><img src="image/arrow.png">BOOK AN APPOINTMENT</h1>
                                            <div class="form-fields">
                                                <?php 
                                                   if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                                                         $email = $_POST['email'];
                                                         $mobile = $_POST['mobile'];
                                                         $gender = $_POST['gender'];
                                                         $message = $_POST['message'];

                                                         $subject = "Contact Us Form - ".$email." ".$mobile;
                                                         $email_message = "Email: ".$email."\nMobile: ".$mobile."\nGender: ".$gender."\nMessage: ".$message;

                                                         $from = "no-reply@minusslimming.com";
                                                         $to = "minus.slimming@gmail.com";

                                                         mail($to, $subject, $email_message, "From: ".$from) ;
                                                         echo "<div class=\"alert alert-success\" role=\"alert\">Thank for booking an appointment.</div>";
                                                    } 
                                                ?>
                                                 <input type="text" class="form-control required" placeholder="Name" name="from"  title="Field Required">
                                                <input type="email" class="form-control required" placeholder="Email" name="email">
                                                <input type="number"   class="form-control required" placeholder="Mobile No" name="mobile">
                                                <input type="text" class="form-control required" placeholder="Gender" name="gender">
                                                <textarea class="form-control required" placeholder="Services" name="message"></textarea>
                                                <input type="submit" class="form-control required" name="submit" value="Submit"/>
                                            </div>
                                          </form>
                                           
                                        <div class="gallery">
                                        <a href="./image/about/photo_1.JPG" title="2 BHK" data-gallery>
                                            <img src="./image/about/clinic.jpg" class="img-responsive">
                                        </a>
                                        <a href="./image/about/photo_2.JPG" title="2 BHK" data-gallery class="hide">
                                            <img src="./image/about/photo_2.JPG" alt="2 BHK" class="img-responsive">
                                        </a>
                                        <a href="./image/about/photo_3.JPG" title="2 BHK" data-gallery class="hide">
                                            <img src="./image/about/photo_2.JPG" alt="2 BHK" class="img-responsive">
                                        </a>
                                       <a href="./image/about/photo_4.JPG" title="2 BHK" data-gallery class="hide">
                                            <img src="./image/about/photo_4.JPG" alt="2 BHK" class="img-responsive">
                                        </a>  
                                         <a href="./image/about/photo_5.JPG" title="2 BHK" data-gallery class="hide">
                                            <img src="./image/about/photo_5.JPG" alt="2 BHK" class="img-responsive">
                                        </a>     
                                         
                                    </div>
                                    
                                        </div>
                              </div>
                          </div>
          </div>
                                
                        <div class="footer">
                            <div class="container1" >
                                <div class="row footer-container">
                                    <div class="col-xs-offset-0 col-md-offset-0 col-md-4 black" style="padding-top:14px"><div class="desc"><img src="image/footer.png"/></div></div>
                                    <div class="col-xs-offset-0 col-md-offset-0 col-md-4 time">
                                    <div class="desc">    <div class="middle-footer">CLINIC TIMINGS</div>
                                    <div>Tue - Sat: 8.00 am to 8.00 pm
<br>
                                        Sun: 8.00 am to 6.00 pm<br>
                                        Monday Closed
                                    </div> 
                                    </div>
                                    </div>
                                    <div class="col-xs-offset-0 col-md-offset-0 col-md-4 social-black" style="padding-left:85px">
                                       <div class="desc"> 
                                           <div class="social-footer">CONNECT WITH US</div>
                                             <div class="img-social">
                                                   <a href="http://www.facebook.com/minusslimming" target="_blank"><img src="image/fb.png" ></a> 
                                                 <a href="http://www.twitter.com/minusslimming.com" target="_blank">  <img src="image/twitter.png"/></a>
                                                 <a href="http://www.minusslimming.blogspot.in" target="_blank">  <img src="image/print.png"/> </a>
                                         </div>
                                      </div>
                                    </div>
                                </div>
                                <div class="row base-container">
                                    <div class="col-md-12 base">
                                       <p>&copy; Copyright 2014 Minus Slimming Centre. All rights reserved.</p>
                                       <p>
                                           Disclaimer: Results may vary from person to person depending upon age, sex, basal 
                                           metabolic rate, medical history, family history, lifestyle and physical activity.
                                       </p>
                                      <p>
                                           All treatments and after care are suggested by expert doctors of clinic and customized 
                                           as per individual requirement to give best possible results.
                                             <br>
                                      Website Design: <a href="http://www.realdreemz.com" target="_blank" class="style1">Realdreemz</a> </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                            
                         <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
                        <script src="js/bootstrap.js"></script>  
                        <script src="http://blueimp.github.io/Gallery/js/jquery.blueimp-gallery.min.js"></script>
                            <script src="js/bootstrap-image-gallery.min.js"></script>    
                        <script src="js/bmi.js"></script>
                            <script src="js/base.js"></script>
                             <script src="js/jquery.validate.min.js"></script>

                        
                        <script>
                            $(document).ready(function(){
                                $('#signup').validate();
                                
                            });
                        </script> 
    </div>
                     <div id="blueimp-gallery" class="blueimp-gallery" data-use-bootstrap-modal="false">
                    <!-- The container for the modal slides -->
                    <div class="slides"></div>
                    <!-- Controls for the borderless lightbox -->
                    <h3 class="title"></h3>
                    <a class="prev"><</a>
                    <a class="next">></a>
                    <a class="close">X</a>
                    <a class="play-pause"></a>
                    <ol class="indicator"></ol>
                    <!-- The modal dialog, which will be used to wrap the lightbox content -->
                    <div class="modal fade">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" aria-hidden="true">&times;</button>
                                    <h4 class="modal-title"></h4>
                                </div>
                                <div class="modal-body next"></div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default pull-left prev">
                                        <i class="glyphicon glyphicon-chevron-left"></i>
                                        Previous
                                    </button>
                                    <button type="button" class="btn btn-primary next">
                                        Next
                                        <i class="glyphicon glyphicon-chevron-right"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                  </div>
        
    </body>
</html>