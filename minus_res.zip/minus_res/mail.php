<?php
  
  $from= $_POST['from'];
  $email= $_POST['email'];
  $mobile= $_POST['mobile'];
  $gender= $_POST['gender'];
  $message= $_POST['message'];
  $subject="new message" ;

  mail("realdreemz@gmail.com", $subject, $message, "From: $from\n") ;
  echo "Your message has been sent";


 ?>