<!DOCTYPE html>
<html>
    <head>
         <title>Minus</title>
        <meta name="viewport" width="device-width,initial-scale=1.0">

        <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link href='http://fonts.googleapis.com/css?family=PT+Sans:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
        <style type="text/css">
<!--
.style1 {color: #AFC621}
-->
        </style>
    </head>
    
    <body>
        <div class="main calorie">
            <div class="header"> 
                <div class="container1">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="container">
                                <div class="logo-section">
                                   <a href="index.php"><img src="image/logo.png" class="logo"/> </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-offset-2 col-md-offset-0 col-md-8">
                            <div class="social"> 
                              <span class="txt" >CONNECT WITH US</span> 
                              <span class="logos">
                                   <a href="http://www.facebook.com/minusslimming" target="_blank">    <img src="image/fb.png" style="margin-bottom:-9px"></a> 
                                <a href="http://www.twitter.com/minusslimming" target="_blank">    <img src="image/twitter.png" style="margin-bottom:-9px"> </a>
                                  <a href="http://www.minusslimming.blogspot.in" target="_blank"> <img src="image/print.png" style="margin-bottom:-9px"> </a>
                              </span>  
                            </div>
                            <div class="menu">
                                <div class="navbar navbar-default menu">
                                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navHeaderCollapse">
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                
                                    </button>
                                
                                    <div class="collapse navbar-collapse navHeaderCollapse">
                                        <ul class="nav navbar-nav navbar-right">
                                            <li> <a href="index.php" >HOME</a> </li>
                                            <li> <a href="about_us.php">ABOUT US</a> </li>
                                            <li> <a href="treatment.php">TREATMENT</a> </li>
                                            <li class="dropdown">
                                                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span style="color:#afc621">TOOLS</span></a>
                                                <ul class="dropdown-menu">
                                                    <li class="il-border "><a href="bmi.php">BMI CALCULATOR</a></li>
                                                    <li class="calorie"><a href="calorie.php">CALORIE CHART </a></li>
                                                </ul>
                                            </li>
                                            <li> <a href="faq.php">FAQS</a> </li>
                                            <li> <a href="career.php">CAREERS</a> </li>
                                            <li> <a href="Contact.php">CONTACT US</a> </li>
                                        </ul>
                                    </div>
                                
                                </div>
                           </div>                        
                       </div>
                  </div>
              </div>
            </div>
            <div class="location">
                <img src="image/calorie%20chart%20banner.jpg" class="img-responsive" alt="Responsive image" style="margin-left:14%">
            </div>
            <div class="grid">
                <div class="container1">
                    <div class="row">
                        <div class="col-md-8 middle-container">
                            <h1> <span class="header-grid" > </span>  </h1>
                            <div class="middle-body"> 
                                <h1> <span class="header-grid" >CALORIE COUNTER </span>  </h1>
                                <div class="table_one"> 
                                        <table>
                                            <tbody>
                                                <tr> <td>Cheese Pizza</td> <td>667 kcal</td> </tr>
                                                <tr> <td>Pavbhaji</td> <td>600 kcal</td> </tr>
                                                <tr> <td>Dahi batata puri(1 plate)</td> <td>565 kcal</td> </tr>
                                                <tr> <td>Pani Puri (6 pcs)</td> <td>150 kcal</td> </tr>
                                                <tr> <td>Veg. Burger</td> <td>438 kcal</td> </tr>
                                                <tr> <td>Sev puri</td> <td>400 kcal</td> </tr>
                                                <tr> <td>1 Samosa</td> <td>369 kcal</td> </tr>
                                                <tr> <td>Sabudana vada (2 pcs)</td> <td>360 kcal</td> </tr>
                                                <tr> <td>1 Wada pav</td> <td>350 kcal</td> </tr>
                                                <tr> <td>Bhel puri (1 plate)</td> <td>320 kcal</td> </tr>
                                                <tr> <td>Sago khichadi (1 vati)</td> <td>316 kcal</td> </tr>
                                                <tr> <td>Malai peda (2 pcs)</td> <td>316 kcal</td> </tr>
                                                <tr> <td>Chicken hakka noodles</td> <td>306 kcal</td> </tr>
                                                <tr> <td>Masala dosa</td> <td>300 kcal</td> </tr>
                                                <tr> <td>Misal (1 plate)</td> <td>300 kcal</td> </tr>
                                                <tr> <td>1 Aloo paratha</td> <td>290 kcal</td> </tr>
                                                <tr> <td>Vanilla milkshake</td> <td>285 kcal</td> </tr>
                                                <tr> <td>1 Medu vada</td> <td>260 kcal</td> </tr>
                                                <tr> <td>Pepsi (1 bottle)</td> <td>150 kcal</td> </tr>
                                                <tr> <td>Coconut chutney (1 tbsp)</td> <td>90 kcal</td> </tr>
                                            </tbody>
                                        </table>
                              </div>

                                <div class="text_1">
                                    <p>
                                        The calories consumed in different physical activities in 30 mins.
                                        The below table is calculated for a 84kg person. The Calories consumed in different
                                        physical activities, increases as the weight of the person increases.
                                    </p>
                                </div>

                                <div class="table_two">
                                    <table>
                                        <tbody>
                                            <tr> <th><span class="bold">ACTIVITY</span></th>
                                                 <th><span class="bold">CALORIES CONSUMED</span></th>
                                            </tr>
                                            <tr> <td>Brisk walk</td> <td>222</td> </tr>
                                            <tr> <td>Tread mill</td> <td>355</td> </tr>
                                            <tr> <td>Swimming</td> <td>266</td> </tr>
                                            <tr> <td>Stroll/ Leisure walk</td> <td>100</td> </tr>
                                            <tr> <td>Yoga</td> <td>178</td> </tr>
                                            <tr> <td>Aerobics</td> <td>311</td> </tr>
                                            <tr> <td>Dancing</td> <td>266</td> </tr>
                                            <tr> <td>Staircase climbing</td> <td>327</td> </tr>
                                            <tr> <td>House hold work</td> <td>175</td> </tr>
                                      </tbody>
                                    </table>
                                </div>    
                            </div>
                        </div>
                        <div class="col-md-4 feedback">
                            <form class="form-horizontal" method="post" name="contact_form" id="signup">
                                <h1 class="top-header"><img src="image/arrow.png">BOOK AN APPOINTMENT</h1>
                                <div class="form-fields">
                                    <?php 
                                       if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                                             
                                             $email = $_POST['email'];
                                             $mobile = $_POST['mobile'];
                                             $gender = $_POST['gender'];
                                             $message = $_POST['message'];

                                             $subject = "Contact Us Form - ".$email." ".$mobile;
                                             $email_message = "Email: ".$email."\nMobile: ".$mobile."\nGender: ".$gender."\nMessage: ".$message;

                                             $from = "no-reply@minusslimming.com";
                                             $to = "minus.slimming@gmail.com";
                                           
                                           function test_input($data)
                                           {
                                              $data = trim($data);
                                              $data = stripslashes($data);
                                              $data = htmlspecialchars($data);
                                              return $data;
                                            }

                                             mail($to, $subject, $email_message, "From: ".$from) ;
                                             echo "<div class=\"alert alert-success\" role=\"alert\">Thank for booking an appointment.</div>";
                                        } 
                                    ?>
                                     <input type="text" class="form-control required" placeholder="Name" name="from"  title="Field Required">
                                                <input type="email" class="form-control required" placeholder="Email" name="email">
                                                <input type="number"   class="form-control required" placeholder="Mobile No" name="mobile">
                                                <input type="text" class="form-control required" placeholder="Gender" name="gender">
                                                <textarea class="form-control required" placeholder="Services" name="message"></textarea>
                                                <input type="submit" class="form-control required" name="submit" value="Submit"/>
                                </div>
                            </form>
                        </div>
                        <div class="row table_four">
                            <table class="table_three" >
                                <tbody>
                                    <tr><th colspan="2"><span class="bold">Calorie Count for Alcoholic beverages:</span></th></tr>
                                    <tr> <td>Beer (1 glass)</td>
                                          <td>600 kcal</td>
                                  </tr>
                                     <tr>
                                            <td>Wine (1 glass)</td>
                                            <td>160 kcal</td>
                                     </tr>
                                     <tr>
                                            <td>Vodka (1 glass)</td>
                                            <td>135 kcal</td>
                                  </tr>
                                      <tr>
                                            <td>Whisky (1 peg)</td>
                                            <td>118 kcal</td>
                                      </tr>
                              </tbody>
                            </table>
                        </div>    
                    </div>          
                </div>
            </div>
                            
                        <div class="footer">
                            <div class="container1" >
                                <div class="row footer-container">
                                    <div class="col-xs-offset-0 col-md-offset-0 col-md-4 black" style="padding-top:14px"><div class="desc"><img src="image/footer.png"/></div></div>
                                    <div class="col-xs-offset-0 col-md-offset-0 col-md-4 time">
                                    <div class="desc">    <div class="middle-footer">CLINIC TIMINGS</div>
                                    <div>Tue - Sat: 8.00 am to 8.00 pm
<br>
                                        Mon: 8.00 am to 6.00 pm<br>
                                        Monday Closed
                                    </div> 
                                    </div>
                                    </div>
                                    <div class="col-xs-offset-0 col-md-offset-0 col-md-4 social-black" style="padding-left:85px">
                                       <div class="desc"> 
                                           <div class="social-footer">CONNECT WITH US</div>
                                             <div class="img-social">
                                                     <a href="http://www.facebook.com/minusslimming" target="_blank"><img src="image/fb.png" ></a> 
                                                 <a href="http://www.twitter.com/minusslimming.com" target="_blank">  <img src="image/twitter.png"/></a>
                                                 <a href="http://www.minusslimming.blogspot.in" target="_blank">  <img src="image/print.png"/> </a>
                                         </div>
                                      </div>
                                    </div>
                                </div>
                                <div class="row base-container">
                                    <div class="col-md-12 base">
                                       <p>&copy; Copyright 2014 Minus Slimming Centre. All rights reserved.</p>
                                       <p>
                                           Disclaimer: Results may vary from person to person depending upon age, sex, basal 
                                           metabolic rate, medical history, family history, lifestyle  and physical activity.
                                       </p>
                                      <p>
                                           All treatments and after care are suggested by expert doctors of clinic and customized 
                                           as per individual requirement to give best possible results.
                                             <br>
                                      Website Design: <a href="http://www.realdreemz.com" target="_blank" class="style1">Realdreemz</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
      
        </div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
        <script src="js/bootstrap.js"></script>
        <script src="js/bmi.js"></script> 
       <script src="js/base.js"></script>
         <script src="js/jquery.validate.min.js"></script>

                        
                        <script>
                            $(document).ready(function(){
                                $
                            });
                        </script> 
    </body>
</html>