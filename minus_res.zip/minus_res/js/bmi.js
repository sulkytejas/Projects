/**
 */

$(document).ready(function() {
    $("#bmi-form input[type=submit]").click(function(evt) {
        evt.preventDefault();
        var wt = parseFloat($("#bmi-form input[name=wt]").val());
        var ht = parseFloat($("#bmi-form input[name=ht]").val())/100;
        var bmi = Math.round((wt/(ht*ht)), 2);
        
        var bmi_result = "";
        if ( bmi < 18.5 ) { 
            bmi_result = "Underweight. ";
        } else if ( bmi >= 18.5 && bmi <= 22.9 ) {
            bmi_result = "Normal";
        } else if ( bmi >= 23 && bmi <= 24.9 ) {
            bmi_result = "Slightly Overweight";
        } else if ( bmi >= 25 && bmi <= 29.9 ) {
            bmi_result = "Overweight";
        } else if ( bmi >= 30 && bmi <= 34.9 ) {
            bmi_result = "Severly Overweight";
        } else if ( bmi >= 35 && bmi <= 39.9 ) {
            bmi_result = "Obese"; 
        } else if (bmi >= 40) {
            bmi_result="Morbidly Obese" ;
        }    
    
        bmi_result = "BMI: " + bmi + "." + bmi_result;
        $("#bmi-form textarea[name=result]").val(bmi_result);
        return false;
    });
    
    $(".menu.navbar-default ul > li").on("mouseenter", function() {
        $(this).addClass("open");
    });
    $(".menu.navbar-default ul > li").on("mouseleave", function() {
        $(this).removeClass("open");
    });
});