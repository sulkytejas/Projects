**
 */

function isSpacesOnly(field) {
    r = field.value.replace(/\s/g, "")
    return (r.length == 0)
  }