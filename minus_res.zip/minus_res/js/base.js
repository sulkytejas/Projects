/**
 */

$(document).ready(function() {

    setTimeout(function() {
        $(".form-fields .alert").hide("slow");
    }, 3000);
});