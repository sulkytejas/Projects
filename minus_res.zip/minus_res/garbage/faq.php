<html>
    <head>
         <title>Minus</title>
        <meta name="viewport" width="device-width,initial-scale=1.0">

        <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link href='http://fonts.googleapis.com/css?family=PT+Sans:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    </head>
    
    <body>
        <div class="main faq">
            <div class="header"> 
                <div class="container1">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="container">
                                <div class="logo-section">
                                    <img src="image/logo.png" class="logo"/>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-offset-2 col-md-offset-0 col-md-8">
                            <div class="social"> 
                              <span class="txt" >CONNECT WITH US</span> 
                              <span class="logos">
                                    <img src="image/fb.png" style="margin-bottom:-9px"> <img src="image/twitter.png" style="margin-bottom:-9px">  <img src="image/print.png" style="margin-bottom:-9px"> 
                              </span>  
                            </div>
                            <div class="menu">
                                <div class="navbar navbar-default menu">
                                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navHeaderCollapse">
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                
                                    </button>
                                
                                    <div class="collapse navbar-collapse navHeaderCollapse">
                                        <ul class="nav navbar-nav navbar-right">
                                            <li> <a href="index.php" >HOME</a> </li>
                                            <li> <a href="about_us.php">ABOUT US</a> </li>
                                            <li> <a href="treatment.php">TREATMENT</a> </li>
                                            <li class="dropdown">
                                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">TOOLS</a>
                                                <ul class="dropdown-menu">
                                                    <li class="il-border "><a href="bmi.php">BMI CALCULATOR</a></li>
                                                    <li class="calorie"><a href="calorie.php">CALORIE CHART</a></li>
                                                </ul>
                                            </li>
                                            <li> <a href="faq.php">FAQS</a> </li>
                                            <li> <a href="career.php">CAREERS</a> </li>
                                            <li> <a href="Contact.php">CONTACT US</a> </li>
                                        </ul>
                                    </div>
                                
                                </div>
                           </div>                        
                       </div>
                     </div>
                  </div>
                </div>
                        <div class="location " >
                            <img src="image/FAQs%20banner.jpg" class="img-responsive" alt="Responsive image" style="margin-left:14%">
                    
                        </div>
                        <div class="grid">
                            <div class="container1">
                                <div class="row">
                                    <div class="col-md-8 middle-container">
                                            <h1> <span class="header-grid" >FAQs </span>  </h1> <br>
                                            <div class="middle-body"> 
                                                <div class="bold">Q: Is U-Lipo Painful ? </div>
                                                 <p>
                                                  <span class="bold">   A:</span> No, ultrasound cavitation is a painless treatment                  </p>
                                     <br>
                                        
                                              <div class="bold">Q: Is U- Lipo safe treatment ? </div>
                                                 <p>
                                                  <span class="bold">   A:</span> Yes, U-Lipo is FDA approved to be a safe and effective. It is a non-surgical Procedure without anaesthesia. It is non invasive and there is no downtime after the treatment you can go right back to you regular routine.                 </p>
                                       </br> 
                                    
                                      <div class="bold">Q: What part of the body can I get U-Lipo done on ? </div>
                                                 <p>
                                                  <span class="bold">   A:</span> Common areas to get the treatment on include thighs, abdomen, buttock, back and double chins, but there is no real limitation as to areas of the body that can be treated.                </p>
                                       </br>  
                                        
                                  <div class="bold">Q: What kind of results can you expect ?</div>
                                                 <p>
                                                  <span class="bold"> A:</span>  The U-Lipo treatment yields immediate and long lasting results. Most clients experience a loss of 8-10 cms or more after a single session with increasing results after each visit. Proper diet and increased physical activity will improve you results and help to maintain the loss of inches.                  </p>
                                       </br>  
                                        
                              <div class="bold">Q: How does the body get rid of the fat after treatment ? </div>
                                                 <p>
                                                  <span class="bold">   A:</span>The body moves the liquefied fat through your Lymphatic system and it get eliminated as waste your body eliminates the fat of a single session in approximately 3 days, so we are recommend an interval of atleast 7 days between each sessions                  </p>
                                       </br>  
                                        
              <div class="bold">Q:Are the results of U-Lipo similar to Liposuction ? </div>
                                                 <p>
                                                  <span class="bold">   A:</span> : The U-Lipo can be considered as a treatment alternative to surgical liposuction. Both treatments are designed to reduce fatty tissues. However, liposuction is invasive while U- Lipo is no invasive.                 </p>
                                       </br>  
                                        
          <div class="bold">Q: Does it work on Cellulite ? </div>
                                                 <p>
                                                  <span class="bold">   A:</span> Yes, low frequency ultrasound (40KHz) generally works well on cellulite by focusing the cavitation effect on the superficial fat tissue best results are obtained when the ultrasound is applied in conjuction with the radio frequency (RF) treatment which helps to tighten and tore the skin cellulite is the appearance of dimpled skin.                  </p>
                                       </br>  
                                        
      <div class="bold">Q: What long term results can I except with ultrasound lipolysis ? </div>
                                                 <p>
                                                  <span class="bold">   A:</span> You can achieve volume reduction of fatty tissues, the results are gradual over a number of weeks as your body clears the broken down fatty tissues. The results can be long lasting provided you follow a healthy diet and exercises programme. However it is very easy to deposit fat again into the tissues. If you over eat, consume too much alcohol.                  </p>
                                       </br>  
                                        
  <div class="bold">Can I lose weight with U-Lipo ? </div>
                                                 <p>
                                                  <span class="bold">   A:</span> U-Lipo is not a treatment for weight loss nor is it a for obesity. Rather is a method for reshaping and toning the body. It is particularly intended to reduce localized fat tissues which are resistant to exercise around the abdomen, buttocks and thighs, saddle bags that won’t easily go away by simple dieting and exercise.                  </p>
                                       </br>  
                                        
  <div class="bold">Q: How many treatments do you recommended getting for each area of the body ? </div>
                                                 <p>
                                                  <span class="bold">   A:</span> For best results 4 to 8 treatments are recommended. However as little as 1  treatment and as many as 12 treatments can be done every week and every 3 days for others area.                 </p>
                                       </br>  
                                        
  <div class="bold">Q: How long do treatment take ? </div>
                                                 <p>
                                                  <span class="bold">   A:</span> Treatments are 60 – 90 minutes long. Treatment times may vary depending on the area being treated but  a typical session will last between 60 – 90 minutes. This includes the preparation, treatment and post treatment procedures.                  </p>
                                       </br>  
                                        
  <div class="bold">Q: Who is not a good candidate for U-Lipo ? </div>
                                                 <p>
                                                  <span class="bold">   A:</span> People who <br>
                                                     <div style="padding-left: 18%">
                                                         -	Have cardiac and vascular diseases.<br>
                                                         -	Are pregnant or nursing<br>
                                                         -	Are going through chemotheraphy<br>
                                                         -	Have liver or kidney disease<br>
                                                         -	Have a pacemaker<br>
                                                         -	Have metal plates in the treatment area<br>
                                                         -	Epilepsy<br>
                                                         -	Are teenaged or younger<br>

                                                     </div>
</p>
                                       </br>  
                                        
  <div class="bold">Q: What is Obesity ? </div>
                                                 <p>
                                                  <span class="bold">   A:</span> Obesity is a medical condition in which excess body fat has aaccumulated to the extent that it may have an adverse effect on health. Leading to reduced life expectancy and/ or increased health problem. Obesity increases the likelihood of various diseases particularly heart diseases, type 2 diabetes, obstructive sleep apnea certain types of cancer and osteoarthritis. A Psyochological disorder which obesity may trigger includes depression, eating disorders, distorted body image. Low social acceptability and low self esteem currently at least 300 million adults worldwide are obese a body mass index (BMI) of over 30 and over one billion are overweight (BMI of more than 27.3 percent for woman and 27.8 percent or more for men) the problem affects virtually all ages and socioeconomic groups.                  </p>
                                       </br>  
                                        
  <div class="bold">Q: What are the Aertiology ? </div>
                                                 <p>
                                                  <span class="bold">   A:</span> Obesity is most commonly caused by a combination of excessive food energy intake, lack of physical activity and genetic susceptibility. It is also caused by endocrine disorders ( Hypothyroidism. Insulin resistance, PCOD ) medications or psychiatric illness.                  </p>
                                       </br>  
                                        
  <div class="bold">Q:Who will do the U-Lipo treatment ? </div>
                                                 <p>
                                                  <span class="bold">   A:</span> U-Lipo treatment is done by qualified & trained doctor’s at Minus Slimming Centre. Unlike other clinics where technicians or therapist do the treatment. Nutritionists and counselors are also available in the centre for pre and post U-Lipo and life style management.                 </p>
                                       </br>  
                                        
  <div class="bold">Q: Do I need to take any precautionary measures before and after the sessions ? </div>
                                                 <p>
                                                  <span class="bold">   A:</span> The treatment is required 2 hrs of fasting and after U-Lipo 45 min brisk walk, cardio or swimming on the day of treatment and 3days U-Lipo diet recommended to help the body metabolize the fat faster. Also it is recommended to take multivitamin & calcium supplement daily.                  </p>
                                       </br>  

  <div class="bold">Q: What result is expected after each treatment ? </div>
                                                 <p>
                                                  <span class="bold">   A:</span> Normally clients lose upto 10 cms and more in each treatment from the target area.                  </p>
                                       </br> 
<p>
    Disclaimer : Results may vary from person to person depending upon age, sex, Basal metabolic rate, medical history, family history, lifestyle and physical activity.
</p>

   
                                        
                                              
                                            </div>

                                            
                                    </div>
                                    
                                              <div class="col-md-4 feedback">
                                           <form class="form-horizontal" method="post" name="contact_form">
                                            <h1 class="top-header"><img src="image/arrow.png">BOOK AN APPOINTMENT</h1>
                                            <div class="form-fields">
                                                <?php 
                                                   if (isset($_POST)) {
                                                         $email = $_POST['email'];
                                                         $mobile = $_POST['mobile'];
                                                         $gender = $_POST['gender'];
                                                         $message = $_POST['message'];

                                                         $subject = "Contact Us Form - ".$email." ".$mobile;
                                                         $email_message = "Email: ".$email."\nMobile: ".$mobile."\nGender: ".$gender."\nMessage: ".$message;

                                                         $from = "no-reply@minusslimming.com";
                                                         $to = "realdreemz@gmail.com";

                                                         mail($to, $subject, $email_message, "From: ".$from) ;
                                                         echo "<div class=\"alert alert-success\" role=\"alert\">Thank for booking an appointment.</div>";
                                                    } 
                                                ?>
                                                <input type="text" class="form-control" placeholder="Name" name="from">
                                                <input type="email" class="form-control" placeholder="Email" name="email">
                                                <input type="text" class="form-control" placeholder="Mobile No" name="mobile">
                                                <input type="text" class="form-control" placeholder="Gender" name="gender">
                                                <textarea class="form-control" placeholder="Services" name="message"></textarea>
                                                <input type="submit" class="form-control" name="submit" value="Submit"/>
                                            </div>
                                          </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                         <div class="footer">
                            <div class="container1" >
                                <div class="row footer-container">
                                    <div class="col-xs-offset-0 col-md-offset-0 col-md-4 black"><div class="desc"><img src="image/footer.png"/></div></div>
                                    <div class="col-xs-offset-0 col-md-offset-0 col-md-4 time">
                                    <div class="desc">    <div class="middle-footer">CLINIC TIMINGS</div><div>Mon-Fri 7:00 AM - 9:00 PM</div> </div>
                                    </div>
                                    <div class="col-xs-offset-0 col-md-offset-0 col-md-4 social-black">
                                       <div class="desc"> 
                                           <div class="social-footer">CONNECT WITH US</div>
                                             <div class="img-social">
                                                   <img src="image/fb.png"/> 
                                                   <img src="image/twitter.png"/>
                                                   <img src="image/print.png"/>
                                               </div>
                                          </div>
                                    </div>
                                </div>
                                <div class="row base-container">
                                    <div class="col-md-12 base">
                                       <p>&copy; Copyright 2014 Minus Slimming Centre. All rights reserved.</p>
                                       <p>
                                           Disclaimer: Results may vary from person to person depending upon age, sex, basal 
                                           metabolic rate, medical history, family history, lifestyle  and physical activity.
                                       </p>
                                       <p>
                                           All treatments and after care are suggested by expert doctors of clinic and customized 
                                           as per individual requirement to give best possible results.
                                       </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                         <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
                        <script src="js/bootstrap.js"></script>    
                        <script src="js/bmi.js"></script>
                    </div>
        
    </body>
</html>