<!DOCTYPE html>
<html>
    <head>
         <title>Minus</title>
        <meta name="viewport" width="device-width,initial-scale=1.0">

        <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link href='http://fonts.googleapis.com/css?family=PT+Sans:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
        <style type="text/css">
<!--
.style1 {color: #AFC621}
-->
        </style>
    </head>
    
    <body>
        <div class="main treatment">
            <div class="header"> 
                <div class="container1">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="container">
                                <div class="logo-section">
                                    <a href="index.php"><img src="image/logo.png" class="logo"/> </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-offset-2 col-md-offset-0 col-md-8">
                            <div class="social"> 
                              <span class="txt" >CONNECT WITH US</span> 
                              <span class="logos">
                                   <a href="http://www.facebook.com/minusslimming" target="_blank">    <img src="image/fb.png" style="margin-bottom:-9px"></a> 
                                <a href="http://www.twitter.com/minusslimming" target="_blank">    <img src="image/twitter.png" style="margin-bottom:-9px"> </a>
                                  <a href="http://www.minusslimming.blogspot.in" target="_blank"> <img src="image/print.png" style="margin-bottom:-9px"> </a>
                              </span>  
                            </div>
                            <div class="menu">
                                <div class="navbar navbar-default menu">
                                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navHeaderCollapse">
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                
                                    </button>
                                
                                    <div class="collapse navbar-collapse navHeaderCollapse">
                                        <ul class="nav navbar-nav navbar-right">
                                            <li> <a href="index.php" >HOME</a> </li>
                                            <li> <a href="about_us.php">ABOUT US</a> </li>
                                            <li>  <a href="treatment.php"><span style="color:#e7387a">TREATMENT</span></a> </li>
                                            <li class="dropdown">
                                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">TOOLS</a>
                                                <ul class="dropdown-menu">
                                                    <li class="il-border "><a href="bmi.php">BMI CALCULATOR</a></li>
                                                    <li class="calorie"><a href="calorie.php">CALORIE CHART</a></li>
                                                </ul>
                                            </li>
                                            <li> <a href="faq.php">FAQS</a> </li>
                                            <li> <a href="career.php">CAREERS</a> </li>
                                            <li> <a href="Contact.php">CONTACT US</a> </li>
                                        </ul>
                                    </div>
                                
                                </div>
                           </div>                        
                       </div>
                  </div>
              </div>
          </div>
                        <div class="location " >
                            <img src="image/treatment%20banner.jpg" class="img-responsive" alt="Responsive image" style="margin-left:12%">
                    
                        </div>
                        <div class="grid">
                            <div class="container1">
                                <div class="row">
                                    <div class="col-md-8 middle-container">
                                            <h1> <span class="header-grid" >CAVITATION </span>  </h1>
                                            <div class="middle-body"> 
                                                <div class="bold">
                                                    CAVITATION IS A FAT REMOVAL BODY SCULPTING TECHNOLOGY WITH NO ANAESTHESIA, NO SCARS, NO DISCOMFORT, NO DOWN TIME AND PRESENT RISK FREE ALTERNATIVE TO LIPOSUCTION. THE RESULT IS INSTANT LOSS OF FAT CELLS.
                                                </div>
                                                <div style="padding-top:13px;padding-bottom:13px;">
                                                     <img src="image/cavity.jpg" class="img-responsive" alt="Responsive image" >
                                                </div>
                                              Cavitation is the latest non-invasive body contouring treatment for localized fat and deep cellulite.<br> <br> 
Cavitation is a natural phenomenon based on low frequency ultrasound. The ultrasound field creates the bubbles in the liquid of the fat cells. Which Gradually grow and implode at certain size. The energy in the form of heat (minor effect) and pressure wave (major effect) is released. As the membrane of fat cells do not have the structural capacity to with stand the vibration the effect of cavitation easily breaks them, while sparing the vascular nervous and muscular tissue. The result is instant fat loss.
                                                <div class="border-treat">
                                                 <h1> <span class="header-grid" >NARF (Non Ablative Radio Frequency) </span>  </h1> <br>
                                                
                                                <div class="bold">
                                                   Tripolar Focus fractional RF is the 3rd generation of RF technology and two times the power of older Bi-polar RF equipment.
                                                </div>
                                                    <div style="padding-top:13px;padding-bottom:13px;">
                                                     <img src="image/legs.jpg" class="img-responsive" alt="Responsive image" >
                                                </div>
                                                    <br>
                                                    <p>
                                                        It utilizes three or more pole / electrodes to deliver the RF energy under the skin this energy is controlled and limited to the treatment area. Key advantages of this technology are high treatment efficacy. No pain as less energy is required shorter treatment services and variable depth of penetration.<br> <br>
Radio frequency helps in toning tightening and re-modelling of the face and skin. It stimulates formation of new collagen deep into the skin leading to collagen contraction and regeneration.Tripolar radio frequency increases intra cellular oxygen diffusion by heating the adipose tissue to a depth of penetration 3-5cms. It stimulates Lymphatic drainage, thereby providing greater elasticity and firmness to the skin.
                                                    </p>
                                             </div>
                                                
                                                <div class="border-treat">
                                                     <h1> <span class="header-grid" >G5 Thrive Stimulation </span>  </h1> <br>
                                                   <p> 1.At the dermic level, It improves extracellular interstitial fluidity resulting in a faster and easier elimination of residual Metabolites.<br>
2.At the vascular level, it stimulates drainage from both, the vascular and Lymphatic system.</p>
                                                </div>
                                                
                                                <div class="border-treat">
                                                    <h1> <span class="header-grid" >VACUUM THERAPY </span>  </h1> <br>
                                                    <p>
                                                     Vacuum therapy is performed through a vacuum system combined with cavitation and Radio frequency to deeply de-congest tissues, thereby reducing the interstitial liquid (drainage) and breaking the hard fibers of cellulites, resulting in a more elastic skin.  
                                                    </p>
                                                </div>
                                            </div>

                                          

                                            

                                            
                                    </div>
                                    
                                        <div class="col-md-4 feedback">
                                             <form class="form-horizontal" method="post" name="contact_form" id="signup">
                                            <h1 class="top-header"><img src="image/arrow.png">BOOK AN APPOINTMENT</h1>
                                            <div class="form-fields">
                                                <?php 
                                                  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                                                         $email = $_POST['email'];
                                                         $mobile = $_POST['mobile'];
                                                         $gender = $_POST['gender'];
                                                         $message = $_POST['message'];

                                                         $subject = "Contact Us Form - ".$email." ".$mobile;
                                                         $email_message = "Email: ".$email."\nMobile: ".$mobile."\nGender: ".$gender."\nMessage: ".$message;

                                                         $from = "no-reply@minusslimming.com";
                                                         $to = "minus.slimming@gmail.com";

                                                         mail($to, $subject, $email_message, "From: ".$from) ;
                                                         echo "<div class=\"alert alert-success\" role=\"alert\"> Thank for booking an appointment.</div>";
                                                    } 
                                                ?>
                                                <input type="text" class="form-control required" placeholder="Name" name="from"  title="Field Required">
                                                <input type="email" class="form-control required" placeholder="Email" name="email">
                                                <input type="number"   class="form-control required" placeholder="Mobile No" name="mobile">
                                                <input type="text" class="form-control required" placeholder="Gender" name="gender">
                                                <textarea class="form-control required" placeholder="Services" name="message"></textarea>
                                                <input type="submit" class="form-control required" name="submit" value="Submit"/>
                                            </div>
                                          </form>
                                        </div>
                              </div>
                          </div>
          </div>
                                     <div class="footer">
                            <div class="container1" >
                                <div class="row footer-container">
                                    <div class="col-xs-offset-0 col-md-offset-0 col-md-4 black" style="padding-top:14px"><div class="desc"><img src="image/footer.png"/></div></div>
                                    <div class="col-xs-offset-0 col-md-offset-0 col-md-4 time">
                                    <div class="desc">    <div class="middle-footer">CLINIC TIMINGS</div>
                                    <div>Tue - Sat: 8.00 am to 8.00 pm
<br>
                                        Sun: 8.00 am to 6.00 pm<br>
                                        Monday Closed
                                    </div> 
                                    </div>
                                    </div>
                                    <div class="col-xs-offset-0 col-md-offset-0 col-md-4 social-black" style="padding-left:85px">
                                       <div class="desc"> 
                                           <div class="social-footer">CONNECT WITH US</div>
                                             <div class="img-social">
                                                     <a href="http://www.facebook.com/minusslimming" target="_blank"><img src="image/fb.png" ></a> 
                                                 <a href="http://www.twitter.com/minusslimming.com" target="_blank">  <img src="image/twitter.png"/></a>
                                                 <a href="http://www.minusslimming.blogspot.in" target="_blank">  <img src="image/print.png"/> </a>
                                         </div>
                                      </div>
                                    </div>
                                </div>
                                <div class="row base-container">
                                    <div class="col-md-12 base">
                                       <p>&copy; Copyright 2014 Minus Slimming Centre. All rights reserved.</p>
                                       <p>
                                           Disclaimer: Results may vary from person to person depending upon age, sex, basal 
                                           metabolic rate, medical history, family history, lifestyle  and physical activity.
                                       </p>
                                      <p>
                                           All treatments and after care are suggested by expert doctors of clinic and customized 
                                           as per individual requirement to give best possible results.
                                             <br>
                                      Website Design: <a href="http://www.realdreemz.com" target="_blank" class="style1">Realdreemz</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                         <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
                        <script src="js/bootstrap.js"></script>    
                        <script src="js/bmi.js"></script>
                        <script src="js/base.js"></script>
             <script src="js/jquery.validate.min.js"></script>

                        
                        <script>
                            $(document).ready(function(){
                                $('#signup').validate();
                                
                            });
                        </script> 
    </div>
        
    </body>
</html>