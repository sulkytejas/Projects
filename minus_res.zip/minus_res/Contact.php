<!DOCTYPE html>
<html>
    <head>
         <title>Minus</title>
        <meta name="viewport" width="device-width,initial-scale=1.0">

        <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link href='http://fonts.googleapis.com/css?family=PT+Sans:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
        <style type="text/css">
<!--
.style1 {color: #AFC621}
-->
        </style>
    </head>
    
    <body>
        <div class="main contact">
            <div class="header"> 
                <div class="container1">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="container">
                                <div class="logo-section">
                                    <a href="index.php"><img src="image/logo.png" class="logo"/> </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-offset-2 col-md-offset-0 col-md-8">
                            <div class="social"> 
                              <span class="txt" >CONNECT WITH US</span> 
                              <span class="logos">
                                   <a href="http://www.facebook.com/minusslimming" target="_blank">    <img src="image/fb.png" style="margin-bottom:-9px"></a> 
                                <a href="http://www.twitter.com/minusslimming" target="_blank">    <img src="image/twitter.png" style="margin-bottom:-9px"> </a>
                                  <a href="http://www.minusslimming.blogspot.in" target="_blank"> <img src="image/print.png" style="margin-bottom:-9px"> </a> 
                              </span>  
                            </div>
                            <div class="menu">
                                <div class="navbar navbar-default menu">
                                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navHeaderCollapse">
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                
                                    </button>
                                
                                    <div class="collapse navbar-collapse navHeaderCollapse">
                                        <ul class="nav navbar-nav navbar-right">
                                            <li> <a href="index.php" >HOME</a> </li>
                                            <li> <a href="about_us.php">ABOUT US</a> </li>
                                            <li> <a href="treatment.php">TREATMENT</a> </li>
                                            <li class="dropdown">
                                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">TOOLS</a>
                                                <ul class="dropdown-menu">
                                                    <li class="il-border "><a href="bmi.php">BMI CALCULATOR</a></li>
                                                    <li class="calorie"><a href="calorie.php">CALORIE CHART</a></li>
                                                </ul>
                                            </li>
                                            <li> <a href="faq.php">FAQS</a> </li>
                                            <li> <a href="career.php">CAREERS</a> </li>
                                            <li> <a href="Contact.php"><span style="color:#afc621">CONTACT US </span></a> </li>
                                        </ul>
                                    </div>
                                
                                </div>
                           </div>                        
                       </div>
                  </div>
              </div>
          </div>
                        <div class="location" style=" background-color: #4a68b0">
                            <div class="row">
                                <div class="col-xs-offset-2 col-md-offset-0 col-md-12">
                                    <img src="image/location.jpg" class="img-responsive" alt="Responsive image" style="margin-left:14%">
                                </div>
                            </div>
                            
                        </div>
                        <div class="grid">
                            <div class="container1">
                                <div class="row">
                                    <div class="col-md-5 middle-container">
                                            <h1> <span class="header-grid" >CONTACT US </span>  </h1>
                                            <div class="middle-body"> 
                                                <div class="bold">Minus Slimming Centre  </div>
                                              <div class="alignment"> 316, B-Wing 3rd Floor,  Plaza Panchsheel,<br>  55, Huges Road,
                                                    Next to Dharam Palace,<br> Gamdevi, Mumbai - 400 007<br>
                                                    Tel.: (022) 2361 7676 / 96998 77788<br>
                                                     <br>
                                                E-mail: <a href="mailto:minus.slimming@gmail.com">minus.slimming@gmail.com</a><br>
                                              <a href="http://www.minusslimming.com">www.minusslimming.com </a>                                              </div>    
                                            </div>

                                          

                                            <div class="map">
                                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3773.3983263196656!2d72.81197!3d18.958008000000003!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7ce0e9e643bf7%3A0xee25e0a6742d2b9d!2sMinus+Slimming+Centre!5e0!3m2!1sen!2sin!4v1409214281153" width="380" height="153" frameborder="0" style="border:0"></iframe>
                                            </div>
                                    </div>
                                    
                                        <div class="col-md-7 feedback">
                                           <form class="form-horizontal" method="post" id="signup">
                                            <h1 class="top-header"><img src="image/arrow.png">ENQUIRY FORM </h1>
                                            <div class="form-fields">
                                                <?php 
                                                   if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                                                         $email = $_POST['email'];
                                                         $mobile = $_POST['mobile'];
                                                         $gender = $_POST['gender'];
                                                         $message = $_POST['message'];

                                                         $subject = "Contact Us Form - ".$email." ".$mobile;
                                                         $email_message = "Email: ".$email."\nMobile: ".$mobile."\nGender: ".$gender."\nMessage: ".$message;

                                                         $from = "no-reply@minusslimming.com";
                                                         $to = "minus.slimming@gmail.com";

                                                         mail($to, $subject, $email_message, "From: ".$from) ;
                                                         echo "<div class=\"alert alert-success\" role=\"alert\">Thank for booking an appointment.</div>";
                                                    } 
                                                ?>
                                                <div class="row">
                                                    <div class="col-md-6" >
                                                        <input type="text" class="form-control required" placeholder="Name" name="from">
                                                    </div>
                                                    <div class="col-md-6" >
                                                        <input type="text" class="form-control required" placeholder="Email" name="email">
                                                    </div>
                                                </div>
                                                 <div class="row">
                                                    <div class="col-md-6" >
                                                        <input type="text" class="form-control required" placeholder="Mobile No." name="mobile">
                                                    </div>
                                                    <div class="col-md-6" >
                                                        <input type="text" class="form-control required" placeholder="Gender" name="gender">
                                                    </div>
                                                </div>
                                                
                                                <textarea class="form-control required" placeholder="Message" name="message"></textarea>
                                                <input type="submit" class="form-control" name="submit" value="SUBMIT"/>
                                            </div>
                                          </form>
                                        </div>
                              </div>
                          </div>
          </div>
                                  <div class="footer">
                            <div class="container1" >
                                <div class="row footer-container">
                                    <div class="col-xs-offset-0 col-md-offset-0 col-md-4 black" style="padding-top:14px"><div class="desc"><img src="image/footer.png"/></div></div>
                                    <div class="col-xs-offset-0 col-md-offset-0 col-md-4 time">
                                    <div class="desc">    <div class="middle-footer">CLINIC TIMINGS</div>
                                    <div>Tue - Sat: 8.00 am to 8.00 pm
<br>
                                        Sun: 8.00 am to 6.00 pm<br>
                                        Monday Closed
                                    </div> 
                                    </div>
                                    </div>
                                    <div class="col-xs-offset-0 col-md-offset-0 col-md-4 social-black" style="padding-left:85px">
                                       <div class="desc"> 
                                           <div class="social-footer">CONNECT WITH US</div>
                                             <div class="img-social">
                                                     <a href="http://www.facebook.com/minusslimming" target="_blank"><img src="image/fb.png" ></a> 
                                                 <a href="http://www.twitter.com/minusslimming.com" target="_blank">  <img src="image/twitter.png"/></a>
                                                 <a href="http://www.minusslimming.blogspot.in" target="_blank">  <img src="image/print.png"/> </a>
                                         </div>
                                      </div>
                                    </div>
                                </div>
                                <div class="row base-container">
                                    <div class="col-md-12 base">
                                       <p>&copy; Copyright 2014 Minus Slimming Centre. All rights reserved.</p>
                                       <p>
                                           Disclaimer: Results may vary from person to person depending upon age, sex, basal 
                                           metabolic rate, medical history, family history, lifestyle  and physical activity.
                                       </p>
                                      <p>
                                           All treatments and after care are suggested by expert doctors of clinic and customized 
                                           as per individual requirement to give best possible results.
                                             <br>
                                      Website Design: <a href="http://www.realdreemz.com" target="_blank" class="style1">Realdreemz</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                         <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
                        <script src="js/bootstrap.js"></script> 
                        <script src="js/bmi.js"></script>
                        <script src="js/base.js"></script>
             <script src="js/jquery.validate.min.js"></script>

                        
                        <script>
                            $(document).ready(function(){
                                $('#signup').validate();
                                
                            });
                        </script> 
    </div>
        
    </body>
</html>