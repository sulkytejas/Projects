<?php 

    function validate() {
        $success = False;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = $_POST['name'];
            $email = $_POST['email'];
            $mobile = $_POST['mobile'];
            $message = $_POST['message'];

            $subject = "Contact Us Form - ".$email." ".$mobile;
            $email_message = "Name: ".$name."\nEmail: ".$email."\nMobile: ".$mobile."\nMessage: ".$message;

            $from = "no-reply@lotusintelligentsystems.com";
            $to = "tejas.pashte@gmail.com";

            mail($to, $subject, $email_message, "From: ".$from);
            if ($name && $email && $mobile && $message) {
                $success = True;
            }
        } 

        $result = array();
        $result['success'] = $success;
        return $result;
    }
?>