<?php
    require_once './twig/lib/Twig/Autoloader.php';
    Twig_Autoloader::register();

    $loader = new Twig_Loader_Filesystem('./templates');
    $twig = new Twig_Environment($loader);

    $success = False;
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = $_POST['name'];
        $email = $_POST['email'];

        $country = $_POST['country'];
        $state = $_POST['state'];

        $mobile = $_POST['mobile'];
        $landline = $_POST['landline'];
        $message = $_POST['message'];

        $subject = "Contact Us Form - ".$email." ".$mobile;
        $email_message = "Name: ".$name."Email: ".$email;
        $email_message = $email_message."\nMobile: ".$mobile."\nLandline: ".$landline;
        $email_message = $email_message."\nCountry: ".$country."\nState: ".$state;
        $email_message = $email_message."\nMessage: ".$message;

        $from = "no-reply@lotusintelligentsystems.com";
        $to = "tejas.pashte@gmail.com";

        mail($to, $subject, $email_message, "From: ".$from);
        if ($email && $message && $mobile) {
            $success = True;
        }
    } 

    echo $twig->render('contact.html', array('success' => $success, ));
?>
