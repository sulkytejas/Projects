/**
 */

$(document).ready(function() {

    // Add slideDown animation to dropdown
//    try {
        $('.dropdown').on('show.bs.dropdown', function(e){
          $(this).find('.dropdown-menu').first().stop(true, true).slideDown();
        });
        $('.dropdown').on('mouseenter', function(e){
          $(this).find('.dropdown-menu').first().stop(true, true).slideDown();
          $(this).addClass("open");
        });

        // Add slideUp animation to dropdown
        $('.dropdown').on('hide.bs.dropdown', function(e){
          $(this).find('.dropdown-menu').first().stop(true, true).slideUp();
        });
        $('.dropdown').on('mouseleave', function(e){
          $(this).find('.dropdown-menu').first().stop(true, true).slideUp();
          $(this).removeClass("open");
        }); 
//    }
//	catch(ex){}


    setTimeout(function() {
        $("#enquiry-form .alert").hide("slow");
    }, 3000);

    // Vertical menu
    var sideslider = $('[data-toggle=collapse-side]');
    var sel = sideslider.attr('data-target');
    var sel2 = sideslider.attr('data-target-2');
    sideslider.click(function(event){
        $(sel).toggleClass('in');
        $(sel2).toggleClass('out');
        console.log(sel2);
    });
     try{
		 jssor_slider1_starter('slider1_container');
	 }  catch (ex){}
   
});